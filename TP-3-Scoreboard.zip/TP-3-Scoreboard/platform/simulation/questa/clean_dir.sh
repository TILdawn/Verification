rm -rf work/ obj/
rm vsim.wlf transcript pkt_to_amber_ack.txt tests.log
